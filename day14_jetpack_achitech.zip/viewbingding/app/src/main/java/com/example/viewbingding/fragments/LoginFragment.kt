package com.example.viewbingding.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.fragment.findNavController
import com.example.viewbingding.R
import com.example.viewbingding.databinding.FragmentLoginBinding
import com.example.viewbingding.viewmodels.LoginViewModel

class LoginFragment : Fragment() {
    private lateinit var binding: FragmentLoginBinding
    private lateinit var viewModel: LoginViewModel
    private lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLoginBinding.inflate(inflater, container, false)
        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        navController = findNavController()
        binding.btnSubmit.setOnClickListener {
            if(viewModel.onLogin()) {
                Toast.makeText(context, "Login successfully!", Toast.LENGTH_SHORT).show()
                navController.navigate(LoginFragmentDirections.actionLoginToHome())
            } else {
                Toast.makeText(context, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnBack.setOnClickListener {
            navController.navigate(LoginFragmentDirections.actionLoginToHome())
        }
        return binding.root
    }
}