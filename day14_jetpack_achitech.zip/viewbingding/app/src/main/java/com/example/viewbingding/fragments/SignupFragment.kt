package com.example.viewbingding.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.fragment.findNavController
import com.example.viewbingding.R
import com.example.viewbingding.databinding.FragmentLoginBinding
import com.example.viewbingding.viewmodels.LoginViewModel

class SignupFragment : Fragment() {
    private lateinit var binding: FragmentLoginBinding
    private lateinit var viewModel: LoginViewModel
    private lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLoginBinding.inflate(inflater, container, false)
        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]
        binding.viewModel = viewModel

        navController = findNavController()
        binding.btnSubmit.setOnClickListener {
            viewModel.onSignup()
            navController.navigate(SignupFragmentDirections.actionSignupToHome())
        }
        binding.btnBack.setOnClickListener {
            navController.navigate(SignupFragmentDirections.actionSignupToHome())
        }
        return binding.root
    }
}