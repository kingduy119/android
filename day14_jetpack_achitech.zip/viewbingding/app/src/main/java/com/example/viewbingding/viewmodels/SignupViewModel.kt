package com.example.viewbingding.viewmodels

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel

class SignupViewModel(application: Application) : AndroidViewModel(application) {
    private val sharedPreferences = application.getSharedPreferences("app", Context.MODE_PRIVATE)
    var username: String =  ""
    var password: String = ""

    fun onSubmit() {
        storeTokenToStorage("$username$password")
    }

    private fun storeTokenToStorage(token: String) {
        sharedPreferences.edit().putString("token", token).apply()
    }
}