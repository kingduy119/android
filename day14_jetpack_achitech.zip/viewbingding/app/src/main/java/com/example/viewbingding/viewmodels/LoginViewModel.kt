package com.example.viewbingding.viewmodels

import android.app.Application
import android.content.Context
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    private val sharedPreferences = application.getSharedPreferences("app", Context.MODE_PRIVATE)
    var username: String =  ""
    var password: String = ""

    fun onLogin(): Boolean {
        val token = sharedPreferences.getString("token", null)
        return token != null && token.isNotEmpty() && token == "$username$password" && isTokenValid(token)
    }
    fun onSignup(): Boolean {
        val token = "$username$password"
        storeTokenToStorage(token)
        return true
    }

    private fun isTokenValid(token: String): Boolean {
        return true
    }
    private fun storeTokenToStorage(token: String) {
        sharedPreferences.edit().putString("token", token).apply()
    }
}