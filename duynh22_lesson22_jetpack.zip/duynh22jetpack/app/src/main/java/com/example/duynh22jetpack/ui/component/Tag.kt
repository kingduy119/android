package com.example.duynh22jetpack.ui.component

import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.duynh22jetpack.data.Tag
import com.example.duynh22jetpack.data.tags
import com.example.duynh22jetpack.ui.component.common.Section


@Composable
fun TagsSection() {
    Section("Tags", "show all(200+") {
        ListTags(tags = tags)
    }
}

@Composable
fun ListTags(tags: List<Tag>) {
    Column() {
        tags.forEach() {tag ->
            TagItem(tag)
            Spacer(modifier = Modifier.height(19.dp))
        }
    }
}

@Composable
fun TagItem(tag: Tag, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text("#${tag.label}")
        Spacer(modifier = Modifier.height(10.dp))
        Row {
            Text("45k followers")
            Text("   •   7,345 Recipes", color = Color.Gray)
        }
    }
}