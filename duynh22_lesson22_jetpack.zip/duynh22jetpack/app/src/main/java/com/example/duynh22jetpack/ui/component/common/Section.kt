package com.example.duynh22jetpack.ui.component.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.duynh22jetpack.ui.theme.Green

@Composable
fun Section(
    startText: String = "",
    endText: String = "",
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Column(modifier = modifier) {
        SectionHeader(startText, endText)
        Spacer(modifier = Modifier.height(15.dp))
        content()
        Spacer(modifier = Modifier.height(50.dp))
    }
}

@Composable
fun SectionHeader(startText: String = "", endText: String = "") {
    Row(modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surface)
        .padding(8.dp)
    ) {
        Text(
            text = startText, modifier = Modifier.weight(1f),
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = endText,
            color = Green,
            fontWeight = FontWeight.Bold
        )
    }
}