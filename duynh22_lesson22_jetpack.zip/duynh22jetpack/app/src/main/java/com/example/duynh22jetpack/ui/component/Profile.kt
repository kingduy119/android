package com.example.duynh22jetpack.ui.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.duynh22jetpack.data.Profile
import com.example.duynh22jetpack.data.profiles
import com.example.duynh22jetpack.ui.component.common.CircleAvatar
import com.example.duynh22jetpack.ui.component.common.Section


@Preview
@Composable
fun ProfilesSection() {
    Section("Profiles", "show all(42+)",
        modifier = Modifier.background(Color.White)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            profiles.forEach { profile ->
                ProfileItem(
                    profile,
                    modifier = Modifier
                        .padding(horizontal = 9.dp)
                        .weight(1f)
                        .fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun ProfileItem(profile: Profile, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        ProfileHeader(profile)
        ProfileBody(profile)
    }
}

@Composable
fun ProfileHeader(profile: Profile) {
    Box(
        modifier = Modifier
            .size(width = 172.dp, height = 110.dp)
            .padding(bottom = 30.dp)
    ) {
        Image(
            painter = painterResource(profile.background),
            contentScale = ContentScale.Crop,
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .blur(
                    radiusX = 1.dp,
                    radiusY = 1.dp,
                    edgeTreatment = BlurredEdgeTreatment.Unbounded
                )
        )
        Box(modifier = Modifier
            .size(80.dp)
            .align(Alignment.BottomCenter)
            .offset(y = 30.dp)
        ) {
            CircleAvatar(profile.avatar)
        }
    }
}

@Composable
fun ProfileBody(profile: Profile ,modifier: Modifier = Modifier) {
    fun Int.toCustomString(): String {
        if(this < 1000) return this.toString()
        val slug = if(this%1000 != 0) "+" else ""
        return "${this/1000}k${slug}"
    }
    Row(modifier = modifier) {
        val modifierColum = Modifier
            .weight(1f)
            .widthIn(max = 100.dp)
        Column(modifier = modifierColum, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = profile.recipes.toCustomString(), modifier = Modifier)
            Text("Recipes")
        }
        Column(modifier = modifierColum, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(profile.followers.toCustomString())
            Text("Followers")
        }
    }
}