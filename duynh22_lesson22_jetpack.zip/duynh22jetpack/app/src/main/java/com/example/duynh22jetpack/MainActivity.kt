package com.example.duynh22jetpack

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.duynh22jetpack.ui.component.ProfilesSection
import com.example.duynh22jetpack.ui.component.RecipesSection
import com.example.duynh22jetpack.ui.component.TagsSection
import com.example.duynh22jetpack.ui.theme.DuyNH22Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            App()
        }
    }
}

@Preview
@Composable
fun AppPreview() {
    DuyNH22Theme {
        App()
    }
}

@Composable
fun App() {
    DuyNH22Theme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Searchbar()
            LazyColumn(modifier = Modifier.padding(horizontal = 25.dp)) {
                item {
                    RecipesSection()
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                }
                item {
                    ProfilesSection()
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                }
                item {
                    TagsSection()
                }
            }
        }
    }
}

@Composable
fun AppScaffold() {
    var searchText by remember { mutableStateOf("") }
    Scaffold(
        content = {
            LazyColumn(modifier = Modifier.padding(horizontal = 25.dp)) {
                item {
                    OutlinedTextField(
                        value = searchText,
                        onValueChange = { searchText = it },
                        label = { Text(text = "Search") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    RecipesSection()
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                }
                item {
                    ProfilesSection()
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Searchbar() {
    var searchText by rememberSaveable { mutableStateOf("") }
    var active by rememberSaveable { mutableStateOf(false) }

    Box(
        Modifier
            .zIndex(1f)
            .fillMaxWidth()) {
        SearchBar(
            modifier = Modifier.align(Alignment.TopCenter),
            query = searchText,
            onQueryChange = { searchText = it },
            onSearch = { active = false },
            active = active,
            onActiveChange = { active = it },
            placeholder = { Text("Search") },
            colors = SearchBarDefaults.colors(containerColor = Color.White),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = { Icon(Icons.Default.Menu, contentDescription = null) }
        ){}
    }
}