package com.example.duynh22jetpack.ui.component

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.duynh22jetpack.data.Post
import com.example.duynh22jetpack.data.posts
import com.example.duynh22jetpack.ui.component.common.Section

@Composable
@Preview
fun RecipesSection() {
    Section("Recipes", "show all (200+)",
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        ListPosts()
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ListPosts() {
    val perSlide = 3
    var pageCount = posts.size / perSlide
    pageCount += if(posts.size % perSlide != 0) 1 else 0

    HorizontalPager(
        pageCount = pageCount,
        modifier = Modifier
            .fillMaxWidth()
    ) { page ->
        val startIdx = page * perSlide
        val endIdx = startIdx + listOf(posts.size - startIdx, perSlide).min()
        val listShow = posts.subList(startIdx, endIdx)
        Row(
            modifier = Modifier.fillMaxWidth()
        ) {
            listShow.forEach {post ->
                PostItem(
                    post = post,
                    modifier = Modifier
                        .padding(6.dp)
                        .weight(1f)
                        .fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun PostItem(post: Post, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(0.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.background(Color.White),
            verticalArrangement = Arrangement.Top,
        ) {
            Image(
                painter = painterResource(post.thumbnail),
                contentDescription = "contentDescription",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth()
            )
            Text(post.title)
        }
    }
}





















