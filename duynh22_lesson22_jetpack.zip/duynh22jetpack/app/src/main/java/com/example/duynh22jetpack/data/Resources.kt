package com.example.duynh22jetpack.data

import androidx.annotation.DrawableRes
import com.example.duynh22jetpack.R

data class Post (
    val title: String,
    @DrawableRes val thumbnail: Int
)

val posts = listOf(
    Post("Banana and Mandarin Buns", R.drawable.img),
    Post("Coconut Pound Cake", R.drawable.img),
    Post("Cardamom and Cranberry Pastry", R.drawable.img_3),
    Post("Banana and Mandarin Buns", R.drawable.img),
    Post("Coconut Pound Cake", R.drawable.img),
    Post("Cardamom and Cranberry Pastry", R.drawable.img_3),
    Post("Banana and Mandarin Buns", R.drawable.img),
    Post("Coconut Pound Cake", R.drawable.img),
    Post("Cardamom and Cranberry Pastry", R.drawable.img_3),
)

data class Profile (
    val name: String,
    @DrawableRes val background: Int,
    @DrawableRes val avatar: Int,
    val recipes: Int = 0,
    val followers: Int = 0
)

val profiles = listOf(
    Profile("Jennifer Lawred", R.drawable.bg_1, R.drawable.avatar, 289, 8900),
    Profile("Pan Hyuk", R.drawable.bg_2, R.drawable.avatar, 289, 8000),
)

data class Tag(
    val label: String,
    val recipes: Int,
    val followers: Int
)

val tags = listOf(
    Tag("sweets", 45000, 7345),
    Tag("sweetsjam", 45000, 7345),
    Tag("sweetpancake", 45000, 7345),
    Tag("sweetsbrunch", 45000, 7345),
)

