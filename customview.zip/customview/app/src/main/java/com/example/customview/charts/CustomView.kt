package com.example.customview.charts

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import com.example.customview.R
import java.text.DecimalFormat

@SuppressLint("Recycle")
class CustomView(context: Context, attrs: AttributeSet): View(context, attrs) {
    private var widthSize = 0f
    private var heightSize = 0f
    private var rowHeight = 0
    private val animDuration = 5000
    private val framesPerSecond = 60
    private val startTime = System.currentTimeMillis()
    private val currencies = listOf("1000000", "2000000", "3000000", "4000000")

    private val paintCurrency = Paint(Paint.ANTI_ALIAS_FLAG)
    private val paintLines = Paint(Paint.ANTI_ALIAS_FLAG)
    private val paintBaseline = Paint(Paint.ANTI_ALIAS_FLAG)
    private val paintText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 50f
    }
    private val fake = 2200000

    init {
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.CustomView)
        paintLines.apply {
            color = typedArray.getColor(R.styleable.CustomView_linesColor, Color.YELLOW)
            style = Paint.Style.FILL_AND_STROKE
            strokeWidth = 6f
            pathEffect = DashPathEffect( floatArrayOf(10f, 15f), 1f )
        }
        paintCurrency.apply {
            color = typedArray.getColor(R.styleable.CustomView_currencyColor, Color.GRAY)
            style = Paint.Style.FILL_AND_STROKE
            textSize = 50f
            strokeWidth = 6f
            pathEffect = DashPathEffect( floatArrayOf(10f, 15f), 1f )
        }
        paintBaseline.apply {
            color = typedArray.getColor(R.styleable.CustomView_baselineColor, Color.BLUE)
            style = Paint.Style.FILL
            strokeWidth = 6f
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        widthSize = MeasureSpec.getSize(widthMeasureSpec).toFloat()
        heightSize = MeasureSpec.getSize(heightMeasureSpec).toFloat() * 9 / 10
        rowHeight = (heightSize / (currencies.size + 1)).toInt()
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        val elapsedTime = System.currentTimeMillis() - startTime

        drawCurrencies(canvas)
        drawLines(canvas)
        drawBaseLine(canvas)

        if(elapsedTime < animDuration.toLong()) {
            this.postInvalidateDelayed((1000/framesPerSecond).toLong())
        }
    }
    private fun drawCurrencies(canvas: Canvas?) {
        val x = widthSize * 8 / 10
        canvas?.drawLine(0f, heightSize, x, heightSize, paintCurrency)
        canvas?.drawText("0", x, heightSize, paintCurrency)

        for((index , value ) in currencies.withIndex()) {
            val y = heightSize - rowHeight * (index + 1)
            canvas?.drawLine(0f, y, x, y, paintCurrency)
            canvas?.drawText(DecimalFormat("#,###").format(value.toDouble()), x, y, paintCurrency)
        }
    }
    private  fun drawLines(canvas: Canvas?) {
        val percent = ((fake % 1000000) / 100000).toFloat() / 10f
        val y = heightSize - (rowHeight * 2) - (rowHeight * percent)
        canvas?.drawLines(
            floatArrayOf(0f, heightSize, widthSize * 8 / 10, y),
            paintLines
        )
    }
    private fun drawBaseLine(canvas: Canvas?) {
        val text = "Max ${DecimalFormat("#,###").format(fake)}"
        val percent = ((fake % 1000000) / 100000).toFloat() / 10f
        val y = heightSize - (rowHeight * 2) - (rowHeight * percent)
        val rect = RectF(0f, y, 30f * text.length.toFloat(),y - paintText.textSize)

        canvas?.drawRect(rect, paintBaseline)
        canvas?.drawLine(rect.right, rect.top, widthSize * 8 / 10, rect.top, paintBaseline)
        canvas?.drawText(text, 0f, y, paintText)
    }
}