package com.example.gettingdata

import android.app.Application
import com.example.gettingdata.model.UserDatabase

class MyApplication: Application() {
    val userDatabase: UserDatabase by lazy { UserDatabase.getDatabase(this) }
}