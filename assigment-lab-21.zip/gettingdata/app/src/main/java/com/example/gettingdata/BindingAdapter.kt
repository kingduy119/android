package com.example.gettingdata

import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.gettingdata.model.User
import com.example.gettingdata.user.UserAdapter

@BindingAdapter("listUsers")
fun bindRecyclerView(recyclerView: RecyclerView, data: List<User>?) {
    val adapter = recyclerView.adapter as UserAdapter
    adapter.submitList(data)
}