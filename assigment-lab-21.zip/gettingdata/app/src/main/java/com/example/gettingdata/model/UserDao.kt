package com.example.gettingdata.model

import androidx.room.*
import kotlinx.coroutines.flow.Flow


@Dao
interface UserDao {
    @Query("SELECT * FROM users")
    fun getEntities(): Flow< List<User> >

    @Query("SELECT * FROM users WHERE id = :id")
    fun getById(id: String): User

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertOne(user: User)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(users: List<User>)

    @Delete
    fun delete(user: User)
}