package com.example.gettingdata.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gettingdata.model.User
import com.example.gettingdata.network.RetrofitClient
import kotlinx.coroutines.launch

class UserViewModel : ViewModel() {
    private val _users = MutableLiveData< List<User> >()
    val users: LiveData< List<User> > = _users

    init {
        getUsers()
    }
    private fun getUsers() {
        viewModelScope.launch {
            try {
                _users.value = RetrofitClient.userService.getEntities().users
            } catch (e: Exception) {
                _users.value = listOf()
            }
        }
    }
}

