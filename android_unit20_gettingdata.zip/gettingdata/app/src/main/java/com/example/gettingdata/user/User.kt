package com.example.gettingdata.user

import android.annotation.SuppressLint
import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.google.gson.annotations.SerializedName
import retrofit2.Call
import retrofit2.http.GET

@Entity(tableName = "users")
data class User(
    @PrimaryKey @SerializedName("id") val id: Int = 0,

    @SerializedName("firstName")
    val firstName: String = "",

    @SerializedName("lastName")
    val lastName: String = "",
)

data class UserResponse(
    val users: List<User>
)

@Dao
interface UserDao {
    @Query("SELECT * FROM users")
    fun getEntities(): List<User>

    @Query("SELECT * FROM users WHERE id = :id")
    fun getById(id: String): User

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertOne(user: User)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(users: List<User>)

    @Delete
    fun delete(user: User)
}

interface UserService {
    @GET("users")
    fun getEntities(): Call<UserResponse>
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    @SuppressLint("Range")
    override fun migrate(database: SupportSQLiteDatabase) {
        database.execSQL("""
            CREATE TABLE IF NOT EXISTS 'Users' (
                'id' INTEGER,
                'firstName' TEXT,
                'lastName' TEXT,
                PRIMARY KEY('id')
            )
        """.trimIndent())
    }
}

@Database(
    version = 2,
    entities = [User::class],
    exportSchema = true
)
abstract class UserDatabase : RoomDatabase() {
    abstract val userDao: UserDao

    companion object {
        private var instance: UserDatabase? = null
        fun getInstance(context: Context): UserDatabase {
            if(instance == null) {
                instance = Room.databaseBuilder(
                    context.applicationContext,
                    UserDatabase::class.java,
                    "kdi_data"
                )
                .addMigrations(MIGRATION_1_2)
                .build()
            }
            return instance as UserDatabase
        }
    }
}



