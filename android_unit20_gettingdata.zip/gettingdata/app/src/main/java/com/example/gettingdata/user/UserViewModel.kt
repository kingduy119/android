package com.example.gettingdata.user

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.*
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

sealed class Result<out T> {
    data class Success<out T>(val data: T) : Result<T>()
    data class Failure(val error: Throwable) : Result<Nothing>()
}

class UserViewModel(context: Context) : ViewModel() {
    private val _users = MutableLiveData< List<User> >()
    val users: LiveData< List<User> > = _users

    private var userRepository = UserRepository(context)

    fun fetchEntities() {
        viewModelScope.launch {
            try {
                val result = userRepository.getEntities()
                _users.value = result
                Log.d("UserViewModel", result.toString())
            } catch (e: Exception) {
                Result.Failure(e)
            }
        }
    }

    override fun onCleared() { super.onCleared() } // Dispose All your Subscriptions to avoid memory leaks
}