package com.example.gettingdata.user

import android.content.Context
import com.example.gettingdata.api.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UserRepository() {
    private lateinit var userDao: UserDao
    private lateinit var userService: UserService

    constructor(context: Context) : this() {
        userDao = UserDatabase.getInstance(context).userDao
        userService = RetrofitClient.userService
    }

    suspend fun getEntities() : List<User> {
        return withContext(Dispatchers.IO) {
            val cache = userDao.getEntities()
            cache.ifEmpty {
                val response = userService.getEntities().execute()
                if(response.isSuccessful) {
                    response.body()?.users?.let {
                        userDao.insertAll(it)
                    }
                }
                userDao.getEntities()
            }
        }
    }
}

