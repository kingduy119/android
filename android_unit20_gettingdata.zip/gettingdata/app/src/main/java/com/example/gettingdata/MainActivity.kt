package com.example.gettingdata

import android.os.Binder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import androidx.room.Room
import com.example.gettingdata.api.RetrofitClient
import com.example.gettingdata.databinding.ActivityMainBinding
import com.example.gettingdata.user.*

val test = listOf(
    User(0, "Duy", "Hoang"),
    User(1, "King", "Duy"),
)

@Suppress("UNCHECKED_CAST")
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var userVM: UserViewModel
    private lateinit var userAdapter: UserAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userAdapter = UserAdapter()
        binding.rvUsers.apply {
            layoutManager = LinearLayoutManager(applicationContext, RecyclerView.VERTICAL, false)
            adapter = this@MainActivity.userAdapter
        }

        userVM = ViewModelProvider(this, object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return UserViewModel(applicationContext) as T
            }
        })[UserViewModel::class.java]
        userVM.fetchEntities()
        userVM.users.observe(this) { users ->
            userAdapter.setUsers(users)
            userAdapter.notifyDataSetChanged()
        }
    }
}