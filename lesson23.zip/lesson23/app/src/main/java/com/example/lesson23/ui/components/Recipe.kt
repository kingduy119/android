package com.example.lesson23.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.lesson23.R
import com.example.lesson23.data.recipes
import com.example.lesson23.providers.Provider
import com.example.lesson23.ui_common.CarouselImages

data class MImage(@DrawableRes val id: Int)

data class Recipe (
    val id: Int,
    var title: String,
    var isLiked: Boolean,
    var images: List<MImage>
)

@Composable
fun ListRecipes(provider: Provider) {
    provider.mRecipes.forEach {recipe ->
        RecipeItem(
            recipe,
            onLike = { provider.onLike(recipe) },
            modifier = Modifier.padding(bottom = 16.dp)
        )
    }
}


@Composable
fun RecipeItem(
    recipe: Recipe,
    onLike: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isLiked = remember { mutableStateOf(recipe.isLiked) }
    val iconHeart = painterResource(if(isLiked.value) R.drawable.heart2 else R.drawable.heart1)

    Card(modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.background(MaterialTheme.colorScheme.onPrimary)) {
            CarouselImages(images = recipe.images)
            Row(modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
            ) {
                Text(
                    fontSize = 16.sp,
                    fontWeight = FontWeight(400),
                    text = recipe.title,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                )
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    Image(painter = iconHeart, contentDescription = null,
                        modifier = Modifier
                            .size(height = 16.dp, width = 19.dp)
                            .zIndex(3f)
                            .clickable {
                                isLiked.value = !isLiked.value
                                onLike()
                            }
                    )
                }
            }
        }
    }
}




