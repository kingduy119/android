package com.example.lesson23.providers

import com.example.lesson23.ui.components.Recipe

class Provider(private val recipes: List<Recipe> = listOf()) {
    var mRecipes = recipes
    fun onSearch(search: String) {
        mRecipes = if(search.isNotEmpty()) recipes.filter { it.title.contains(search, ignoreCase = true)}
        else recipes
    }
    fun onLike(recipe: Recipe) {
        recipes.find { it.id == recipe.id }?.isLiked = !recipe.isLiked
    }
}