package com.example.lesson23.ui_common

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.lesson23.data.recipes
import com.example.lesson23.ui.components.MImage
import com.example.lesson23.ui.theme.BlueDark

@Preview
@Composable
fun CarouselImagesPreview() {
    CarouselImages(recipes[1].images)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CarouselImages(images: List<MImage>) {
    val state = rememberPagerState(
        initialPage = 0
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1.5f)
    ) {
        HorizontalPager(
            state = state,
            pageCount = images.size,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            Image(
                painter = painterResource(images[page].id),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
                .offset(y=(-8).dp)
        ) {
            for(i in images.indices) {
                DotIndicator(
                    isActive = state.currentPage == i,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }
    }
}

@Composable
fun DotIndicator(isActive: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(8.dp)
            .background(
                color = if (isActive) BlueDark else Color.Gray,
                shape = CircleShape
            )
    )
}