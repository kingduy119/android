package com.example.lesson23

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.lesson23.data.recipes
import com.example.lesson23.providers.Provider
import com.example.lesson23.ui.components.ListRecipes
import com.example.lesson23.ui.theme.Lesson23Theme
import com.example.lesson23.ui_common.SearchField

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val provider = Provider(recipes)
    Lesson23Theme {
        var searchQuery by remember { mutableStateOf("") }
        provider.onSearch(searchQuery.trim())

        Scaffold(
            content = {
                LazyColumn(modifier = Modifier.padding(horizontal = 25.dp)) {
                    item {
                        SearchField(
                            modifier = Modifier.padding(top = 20.dp, bottom = 34.dp),
                            searchQuery = searchQuery,
                            onValueChange = {
                                searchQuery = it
                            },
                            onClearSearch = { searchQuery = "" }
                        )
                    }
                    item {
                        ListRecipes(provider)
                    }
                }
            },
        )
    }
}