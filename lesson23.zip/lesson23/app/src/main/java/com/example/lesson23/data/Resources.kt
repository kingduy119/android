package com.example.lesson23.data

import com.example.lesson23.R
import com.example.lesson23.ui.components.MImage
import com.example.lesson23.ui.components.Recipe

val recipes = listOf(
    Recipe(0, "The new method to making breakfast", false, listOf(
        MImage(R.drawable.img2),
        MImage(R.drawable.img3),
        MImage(R.drawable.img1),
    )),
    Recipe(1, "Banana and Mandarin Buns", false, listOf(
        MImage(R.drawable.img1),
        MImage(R.drawable.img2),
        MImage(R.drawable.img3),
    )),
    Recipe(2, "Cardamom and Cranberry Pastry", false, listOf(
        MImage(R.drawable.img1)
    ))
)