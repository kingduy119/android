package com.example.androidunit17.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.androidunit17.R
import com.example.androidunit17.model.Movie

class MovieViewModel: ViewModel() {
    val movies: List<Movie> = listOf(
        Movie("0", R.drawable.image1),
        Movie("2", R.drawable.image2),
        Movie("5", R.drawable.image5)
    )
}