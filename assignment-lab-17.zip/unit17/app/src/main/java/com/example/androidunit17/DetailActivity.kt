package com.example.androidunit17

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import com.example.androidunit17.databinding.ActivityDetailBinding
import com.example.androidunit17.model.Movie
import com.example.androidunit17.viewmodel.MovieViewModel

class DetailActivity : AppCompatActivity() {
    private val viewModel: MovieViewModel by viewModels()
    lateinit var movie: Movie

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDetailBinding.inflate(this.layoutInflater)
        val id = intent.getIntExtra("position", 0)
        binding.movie = viewModel.movies[id]
        setContentView(binding.root)
    }
}