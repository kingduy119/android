package com.example.androidunit17

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.androidunit17.databinding.ActivityMainBinding
import com.example.androidunit17.viewmodel.MovieViewModel


class MainActivity : AppCompatActivity() {
    private val viewModel: MovieViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(this.layoutInflater)
        binding.viewModel = viewModel
        binding.rvPopular.adapter = PopularAdapter()
        binding.rvTopRate.adapter = TopRatedAdapter()
        setContentView(binding.root)
    }
}

