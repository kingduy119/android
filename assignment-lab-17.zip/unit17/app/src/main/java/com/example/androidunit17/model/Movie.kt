package com.example.androidunit17.model

import androidx.annotation.DrawableRes

data class Movie(
    val id: String,
    @DrawableRes val thumbnail: Int
)
