package com.example.androidunit17

import android.widget.ImageView
import android.widget.LinearLayout
import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.androidunit17.model.Movie

@BindingAdapter("imageId")
fun bindBackground(layout: LinearLayout, imageId: Int?) {
    if (imageId != null) {
        layout.setBackgroundResource(imageId)
    }
}

@BindingAdapter("listPopular")
fun bindListPopular(recyclerView: RecyclerView, data: List<Movie>?) {
    val adapter = recyclerView.adapter as PopularAdapter
    adapter.submitList(data)
}

@BindingAdapter("listTopRate")
fun bindListTopRate(recyclerView: RecyclerView, data: List<Movie>?) {
    val adapter = recyclerView.adapter as TopRatedAdapter
    adapter.submitList(data)
}

@BindingAdapter("ivImageId")
fun bindImageViewSrc(imageView: ImageView, ivImageId: Int?) {
    if (ivImageId != null) {
        imageView.setImageResource(ivImageId)
    }
}